class CollegeManager {
    var colleges: [College] = []

    func createCollege(name: String, address: String) {
        let id = colleges.count + 1
        let college = College(id: id, name: name, address: address)
        colleges.append(college)
    }

    func readCollege(id: Int) -> College? {
        return colleges.first(where: { $0.id == id })
    }

    func updateCollege(id: Int, newName: String, newAddress: String) {
        guard let college = readCollege(id: id) else { return }
        college.name = newName
        college.address = newAddress
    }

    func deleteCollege(id: Int) {
        if let index = colleges.firstIndex(where: { $0.id == id }) {
            colleges.remove(at: index)
        }
    }

    func listColleges() -> [College] {
        return colleges
    }

    func searchByCollegeName(name: String) -> [College] {
        return colleges.filter({ $0.name.contains(name) })
    }
}
