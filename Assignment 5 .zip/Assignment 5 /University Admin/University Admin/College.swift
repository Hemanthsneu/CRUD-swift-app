class College {
    var id: Int
    var name: String
    var address: String

    init(id: Int, name: String, address: String) {
        self.id = id
        self.name = name
        self.address = address
    }
}
