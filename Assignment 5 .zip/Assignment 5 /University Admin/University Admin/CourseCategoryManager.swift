class CourseCategoryManager {
    var courseCategories: [CourseCategory] = []

    func createCourseCategory(name: String) {
        let id = courseCategories.count + 1
        let courseCategory = CourseCategory(id: id, name: name)
        courseCategories.append(courseCategory)
    }

    func readCourseCategory(id: Int) -> CourseCategory? {
        return courseCategories.first(where: { $0.id == id })
    }

    func updateCourseCategory(id: Int, newName: String) {
        guard let courseCategory = readCourseCategory(id: id) else { return }
        courseCategory.name = newName
    }

    func deleteCourseCategory(id: Int) {
        if let index = courseCategories.firstIndex(where: { $0.id == id }) {
            courseCategories.remove(at: index)
        }
    }

    func listCourseCategories() -> [CourseCategory] {
        return courseCategories
    }

    func searchByCourseCategoryName(name: String) -> [CourseCategory] {
        return courseCategories.filter({ $0.name.contains(name) })
    }
}
