let programManager = ProgramManager()
let courseManager = CourseManager()
let collegeManager = CollegeManager()
let courseCategoryManager = CourseCategoryManager()

func mainMenu() {
    print("""
    Welcome to University Admin System
    1. Manage Programs
    2. Manage Courses
    3. Manage Colleges
    4. Manage Course Categories
    5. Exit
    """)

    switch readChoice() {
    case 1:
        programMenu()
    case 2:
        courseMenu()
    case 3:
        collegeMenu()
    case 4:
        courseCategoryMenu()
    case 5:
        print("Exiting...")
        return
    default:
        print("Invalid choice.")
        mainMenu()
    }
}

func readChoice() -> Int {
    return Int(readLine() ?? "") ?? 0
}

// Program Management
func programMenu() {
    print("""
    Program Management
    1. Create Program
    2. Read Program by ID
    3. Update Program
    4. Delete Program
    5. List All Programs
    6. Search by Program Name
    7. Return to Main Menu
    """)

    switch readChoice() {
    case 1:
        print("Enter Program Name:")
        let name = readLine() ?? ""
        print("Enter College ID (or leave blank):")
        let college_id = Int(readLine() ?? "")
        programManager.createProgram(name: name, college_id: college_id)
        print("Program created successfully!")
        programMenu()
    case 2:
        print("Enter Program ID:")
        if let id = Int(readLine() ?? ""), let program = programManager.readProgram(id: id) {
            print("ID: \(program.id), Name: \(program.name), College ID: \(program.college_id ?? -1)")
        } else {
            print("Program not found.")
        }
        programMenu()
    case 3:
        print("Enter Program ID to update:")
        if let id = Int(readLine() ?? "") {
            print("Enter new name:")
            let newName = readLine() ?? ""
            print("Enter new College ID (or leave blank):")
            let newCollegeId = Int(readLine() ?? "")
            programManager.updateProgram(id: id, newName: newName, newCollegeId: newCollegeId)
            print("Program updated successfully!")
        } else {
            print("Invalid ID.")
        }
        programMenu()
    case 4:
        print("Enter Program ID to delete:")
        if let id = Int(readLine() ?? "") {
            if courseManager.hasCourses(forProgramId: id) {
                print("Cannot delete program. It has associated courses.")
            } else {
                programManager.deleteProgram(id: id)
                print("Program deleted successfully!")
            }
        } else {
            print("Invalid ID.")
        }
        programMenu()
    case 5:
        let programs = programManager.listPrograms()
        for program in programs {
            print("ID: \(program.id), Name: \(program.name), College ID: \(program.college_id ?? -1)")
        }
        programMenu()
    case 6:
        print("Enter Program Name to search:")
        let name = readLine() ?? ""
        let results = programManager.searchByProgramName(name: name)
        for program in results {
            print("ID: \(program.id), Name: \(program.name)")
        }
        programMenu()
    case 7:
        mainMenu()
    default:
        print("Invalid choice.")
        programMenu()
    }
}

// Course Management
func courseMenu() {
    print("""
    Course Management
    1. Create Course
    2. Read Course by ID
    3. Update Course
    4. Delete Course
    5. List All Courses
    6. Search by Course Name
    7. Return to Main Menu
    """)

    switch readChoice() {
    case 1:
        print("Enter Course Name:")
        let name = readLine() ?? ""
        print("Enter College ID (or leave blank):")
        let college_id = Int(readLine() ?? "")
        print("Enter Program ID (or leave blank):")
        let program_id = Int(readLine() ?? "")
        print("Enter Course Category ID (or leave blank):")
        let course_category_id = Int(readLine() ?? "")
        courseManager.createCourse(name: name, college_id: college_id, program_id: program_id, course_category_id: course_category_id)
        print("Course created successfully!")
        courseMenu()
    case 2:
        print("Enter Course ID:")
        if let id = Int(readLine() ?? ""), let course = courseManager.readCourse(id: id) {
            print("ID: \(course.id), Name: \(course.name), College ID: \(course.college_id ?? -1), Program ID: \(course.program_id ?? -1), Course Category ID: \(course.course_category_id ?? -1)")
        } else {
            print("Course not found.")
        }
        courseMenu()
    case 3:
        print("Enter Course ID to update:")
        if let id = Int(readLine() ?? "") {
            print("Enter new name:")
            let newName = readLine() ?? ""
            print("Enter new College ID (or leave blank):")
            let newCollegeId = Int(readLine() ?? "")
            print("Enter new Program ID (or leave blank):")
            let newProgramId = Int(readLine() ?? "")
            print("Enter new Course Category ID (or leave blank):")
            let newCourseCategoryId = Int(readLine() ?? "")
            courseManager.updateCourse(id: id, newName: newName, newCollegeId: newCollegeId, newProgramId: newProgramId, newCourseCategoryId: newCourseCategoryId)
            print("Course updated successfully!")
        } else {
            print("Invalid ID.")
        }
        courseMenu()
    case 4:
        print("Enter Course ID to delete:")
        if let id = Int(readLine() ?? "") {
            courseManager.deleteCourse(id: id)
            print("Course deleted successfully!")
        } else {
            print("Invalid ID.")
        }
        courseMenu()
    case 5:
        let courses = courseManager.listCourses()
        for course in courses {
            print("ID: \(course.id), Name: \(course.name), College ID: \(course.college_id ?? -1), Program ID: \(course.program_id ?? -1), Course Category ID: \(course.course_category_id ?? -1)")
        }
        courseMenu()
    case 6:
        print("Enter Course Name to search:")
        let name = readLine() ?? ""
        let results = courseManager.searchByCourseName(name: name)
        for course in results {
            print("ID: \(course.id), Name: \(course.name)")
        }
        courseMenu()
    case 7:
        mainMenu()
    default:
        print("Invalid choice.")
        courseMenu()
    }
}

// College Management
func collegeMenu() {
    print("""
    College Management
    1. Create College
    2. Read College by ID
    3. Update College
    4. Delete College
    5. List All Colleges
    6. Search by College Name
    7. Return to Main Menu
    """)

    switch readChoice() {
    case 1:
        print("Enter College Name:")
        let name = readLine() ?? ""
        print("Enter College Address:")
        let address = readLine() ?? ""
        collegeManager.createCollege(name: name, address: address)
        print("College created successfully!")
        collegeMenu()
    case 2:
        print("Enter College ID:")
        if let id = Int(readLine() ?? ""), let college = collegeManager.readCollege(id: id) {
            print("ID: \(college.id), Name: \(college.name), Address: \(college.address)")
        } else {
            print("College not found.")
        }
        collegeMenu()
    case 3:
        print("Enter College ID to update:")
        if let id = Int(readLine() ?? "") {
            print("Enter new name:")
            let newName = readLine() ?? ""
            print("Enter new address:")
            let newAddress = readLine() ?? ""
            collegeManager.updateCollege(id: id, newName: newName, newAddress: newAddress)
            print("College updated successfully!")
        } else {
            print("Invalid ID.")
        }
        collegeMenu()
    case 4:
        print("Enter College ID to delete:")
        if let id = Int(readLine() ?? "") {
            if programManager.hasPrograms(forCollegeId: id) {
                print("Cannot delete college. It has associated programs.")
            } else {
                collegeManager.deleteCollege(id: id)
                print("College deleted successfully!")
            }
        } else {
            print("Invalid ID.")
        }
        collegeMenu()
    case 5:
        let colleges = collegeManager.listColleges()
        for college in colleges {
            print("ID: \(college.id), Name: \(college.name), Address: \(college.address)")
        }
        collegeMenu()
    case 6:
        print("Enter College Name to search:")
        let name = readLine() ?? ""
        let results = collegeManager.searchByCollegeName(name: name)
        for college in results {
            print("ID: \(college.id), Name: \(college.name)")
        }
        collegeMenu()
    case 7:
        mainMenu()
    default:
        print("Invalid choice.")
        collegeMenu()
    }
}

// Course Category Management
func courseCategoryMenu() {
    print("""
    Course Category Management
    1. Create Course Category
    2. Read Course Category by ID
    3. Update Course Category
    4. Delete Course Category
    5. List All Course Categories
    6. Search by Course Category Name
    7. Return to Main Menu
    """)

    switch readChoice() {
    case 1:
        print("Enter Course Category Name:")
        let name = readLine() ?? ""
        courseCategoryManager.createCourseCategory(name: name)
        print("Course Category created successfully!")
        courseCategoryMenu()
    case 2:
        print("Enter Course Category ID:")
        if let id = Int(readLine() ?? ""), let courseCategory = courseCategoryManager.readCourseCategory(id: id) {
            print("ID: \(courseCategory.id), Name: \(courseCategory.name)")
        } else {
            print("Course Category not found.")
        }
        courseCategoryMenu()
    case 3:
        print("Enter Course Category ID to update:")
        if let id = Int(readLine() ?? "") {
            print("Enter new name:")
            let newName = readLine() ?? ""
            courseCategoryManager.updateCourseCategory(id: id, newName: newName)
            print("Course Category updated successfully!")
        } else {
            print("Invalid ID.")
        }
        courseCategoryMenu()
    case 4:
        print("Enter Course Category ID to delete:")
        if let id = Int(readLine() ?? "") {
            courseCategoryManager.deleteCourseCategory(id: id)
            print("Course Category deleted successfully!")
        } else {
            print("Invalid ID.")
        }
        courseCategoryMenu()
    case 5:
        let courseCategories = courseCategoryManager.listCourseCategories()
        for courseCategory in courseCategories {
            print("ID: \(courseCategory.id), Name: \(courseCategory.name)")
        }
        courseCategoryMenu()
    case 6:
        print("Enter Course Category Name to search:")
        let name = readLine() ?? ""
        let results = courseCategoryManager.searchByCourseCategoryName(name: name)
        for courseCategory in results {
            print("ID: \(courseCategory.id), Name: \(courseCategory.name)")
        }
        courseCategoryMenu()
    case 7:
        mainMenu()
    default:
        print("Invalid choice.")
        courseCategoryMenu()
    }
}

mainMenu()

