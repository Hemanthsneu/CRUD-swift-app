class CourseManager {
    var courses: [Course] = []

    func createCourse(name: String, college_id: Int?, program_id: Int?, course_category_id: Int?) {
        let id = courses.count + 1
        let course = Course(id: id, name: name, college_id: college_id, program_id: program_id, course_category_id: course_category_id)
        courses.append(course)
    }

    func readCourse(id: Int) -> Course? {
        return courses.first(where: { $0.id == id })
    }

    func updateCourse(id: Int, newName: String, newCollegeId: Int?, newProgramId: Int?, newCourseCategoryId: Int?) {
        guard let course = readCourse(id: id) else { return }
        course.name = newName
        course.college_id = newCollegeId
        course.program_id = newProgramId
        course.course_category_id = newCourseCategoryId
    }

    func deleteCourse(id: Int) {
        if let index = courses.firstIndex(where: { $0.id == id }) {
            courses.remove(at: index)
        }
    }

    func listCourses() -> [Course] {
        return courses
    }


    func searchByCourseName(name: String) -> [Course] {
        return courses.filter({ $0.name.contains(name) })
    }
    func hasCourses(forProgramId programId: Int) -> Bool {
        return courses.contains { $0.program_id == programId }
    }

}
