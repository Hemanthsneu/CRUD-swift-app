class ProgramManager {
    var programs: [Program] = []

    func createProgram(name: String, college_id: Int?) {
        let id = programs.count + 1
        let program = Program(id: id, name: name, college_id: college_id)
        programs.append(program)
    }

    func readProgram(id: Int) -> Program? {
        return programs.first(where: { $0.id == id })
    }
   

    func updateProgram(id: Int, newName: String, newCollegeId: Int?) {
        guard let program = readProgram(id: id) else { return }
        program.name = newName
        program.college_id = newCollegeId
    }

    func deleteProgram(id: Int) {
        if let index = programs.firstIndex(where: { $0.id == id }) {
            programs.remove(at: index)
        }
    }

    func listPrograms() -> [Program] {
        return programs
    }

    func searchByProgramName(name: String) -> [Program] {
        return programs.filter({ $0.name.contains(name) })
    }
    func hasPrograms(forCollegeId collegeId: Int) -> Bool {
        return programs.contains { $0.college_id == collegeId }
    }

}
