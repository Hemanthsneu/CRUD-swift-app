class Program {
    var id: Int
    var name: String
    var college_id: Int?

    init(id: Int, name: String, college_id: Int?) {
        self.id = id
        self.name = name
        self.college_id = college_id
    }
}
