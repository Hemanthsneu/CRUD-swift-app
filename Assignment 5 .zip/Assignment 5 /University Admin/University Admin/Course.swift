class Course {
    var id: Int
    var name: String
    var college_id: Int?
    var program_id: Int?
    var course_category_id: Int?

    init(id: Int, name: String, college_id: Int?, program_id: Int?, course_category_id: Int?) {
        self.id = id
        self.name = name
        self.college_id = college_id
        self.program_id = program_id
        self.course_category_id = course_category_id
    }
}

